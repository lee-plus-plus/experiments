from .tresnet_sync import TResnetM, TResnetL

tresnetm = TResnetM
tresnetl = TResnetL
