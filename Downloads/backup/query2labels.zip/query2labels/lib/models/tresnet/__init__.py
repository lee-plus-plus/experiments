from .tresnet_sync import TResnetM, TResnetL, TResnetXL
tresnetm = TResnetM
tresnetl = TResnetL
tresnetxl = TResnetXL
tresnetl_21k = TResnetL
