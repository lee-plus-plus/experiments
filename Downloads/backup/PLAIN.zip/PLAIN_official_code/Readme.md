Thanks for your attention to our IJCAI 2023 paper.

 To run our code, please excute the following shell code to run PLAIN. 

```
nohup python -u main_gpu.py --using_lp > demo.log 2>&1 &
```

------

This code package can be used freely for academic, non-profit purposes. The related paper is as follows,

```
@misc{wang2023plain,
    title={Deep Partial Multi-Label Learning with Graph Disambiguation}, 
    author={Haobo Wang and Shisong Yang and Gengyu Lyu and Weiwei Liu and Tianlei Hu and Ke Chen and Songhe Feng and Gang Chen},
    year={2023},
  	booktitle = {IJCAI},
}
```