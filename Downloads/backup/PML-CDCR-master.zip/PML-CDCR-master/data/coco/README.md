Data directory for COCO.

After following all of the data preparation instructions, the top level of this directory should consist of the following files and directories:
* `annotations/`
* `train2014/`
* `val2014/`
* `train_anno.json`
* `val_anno_json`